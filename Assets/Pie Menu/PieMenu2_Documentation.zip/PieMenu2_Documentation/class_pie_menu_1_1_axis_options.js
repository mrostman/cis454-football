var class_pie_menu_1_1_axis_options =
[
    [ "HideCursor", "class_pie_menu_1_1_axis_options.html#a1d4cec745632068c6973bdfb2b07c71f", null ],
    [ "Sensitivity", "class_pie_menu_1_1_axis_options.html#a85617cb10f73842ce8341c25c7a26ffd", null ],
    [ "Treshold", "class_pie_menu_1_1_axis_options.html#a1a953f21e6aa7e959beaa356246011b4", null ],
    [ "XAxis", "class_pie_menu_1_1_axis_options.html#aace877ed504e57a51c814536def03831", null ],
    [ "YAxis", "class_pie_menu_1_1_axis_options.html#ae1ebc7b4e193a932ad70ab608c4a4482", null ]
];