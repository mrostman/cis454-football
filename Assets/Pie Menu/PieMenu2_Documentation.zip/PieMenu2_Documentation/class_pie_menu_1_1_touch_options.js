var class_pie_menu_1_1_touch_options =
[
    [ "checkIfFingerIsOnOption", "class_pie_menu_1_1_touch_options.html#ac220f8d77fcdbd33e4e4f561dcf7e0d6", null ],
    [ "fingerID", "class_pie_menu_1_1_touch_options.html#a5d35a7891140e6caec43839838f6ecf7", null ],
    [ "innerInputRadius", "class_pie_menu_1_1_touch_options.html#aa33bec2acab6d2e0d0f8ae9145ed0163", null ],
    [ "outerInputRadius", "class_pie_menu_1_1_touch_options.html#a834b96f83824b11179262ccee5177fa3", null ]
];